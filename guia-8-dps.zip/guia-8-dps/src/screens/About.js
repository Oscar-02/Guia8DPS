import React from 'react';
import { View, Text } from 'react-native';

export default function Home({navigation}) {
  return (
    <View>
      <Text>Estamos en About</Text>
    </View>
  );
}
