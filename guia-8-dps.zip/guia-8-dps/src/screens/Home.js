import React from 'react';
import { View, Text, Button } from 'react-native';

export default function Home(props) {
  const {navigation} = props

  return (
    <View>
      <Text>Estamos en home</Text>
      <Button title= 'Ir a about' onPress={() => navigation.navigate('about')}/>
    </View>
  );
}
